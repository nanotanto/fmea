<html>
<head>
<meta content="text/html; charset=ISO-8859-1" http-equiv="content-type">
<title>FMEA AIAG-VDA</title>
<link rel="stylesheet" href="http://cdn.webix.com/edge/webix.css" type="text/css">
<script src="http://cdn.webix.com/edge/webix.js" type="text/javascript"></script> 
<link href="{{ asset('codebase/app.css') }}" rel="stylesheet">
<script src="{{ asset('codebase/app.js') }}"></script>
</head>
<body>

</body>
</html