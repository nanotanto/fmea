<html>
<head>
<meta content="text/html; charset=ISO-8859-1" http-equiv="content-type">
<title>FMEA AIAG-VDA</title>
<link rel="stylesheet" href="http://cdn.webix.com/edge/webix.css" type="text/css">
<script src="http://cdn.webix.com/edge/webix.js" type="text/javascript"></script> 
<link href="<?php echo e(asset('codebase/app.css')); ?>" rel="stylesheet">
<script src="<?php echo e(asset('codebase/app.js')); ?>"></script>
</head>
<body>

</body>
</html<?php /**PATH C:\laragon\www\myproject\fmea\fmea\backend\resources\views/index.blade.php ENDPATH**/ ?>